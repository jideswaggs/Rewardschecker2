import yaml

# Simulated project checkers
def check_project(name, address, private_key=None):
    print(f"✅ {name}: Rewards found for {address}")
    if private_key:
        print(f"🔐 {name}: Claim sent [mock tx]")

PROJECTS = [
    "Raydium", "Marinade", "Jupiter", "Lido", "Meteora", "Drift", "Tensor"
]

def run_checker():
    try:
        with open("config.yaml", "r") as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        print("❌ config.yaml not found.")
        return

    address = config["wallet"].get("address")
    private_key = config["wallet"].get("private_key", None)
    auto_claim = config["settings"].get("auto_claim", False)
    selected = config["settings"].get("only_projects", PROJECTS)

    print(f"🔍 Checking for rewards for {address}...\n")

    for project in PROJECTS:
        if project not in selected:
            print(f"⏭️  {project}: Skipped (not selected in config)")
            continue
        check_project(project, address, private_key if auto_claim else None)

    print("\n✅ Done.")

if __name__ == "__main__":
    run_checker()
